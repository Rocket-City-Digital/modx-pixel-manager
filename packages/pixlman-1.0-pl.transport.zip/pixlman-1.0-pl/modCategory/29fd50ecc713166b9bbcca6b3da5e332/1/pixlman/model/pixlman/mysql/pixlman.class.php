<?php
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/pixlman.class.php');
class Pixlman_mysql extends Pixlman {
    public function __construct(& $xpdo) {
        parent :: __construct($xpdo);
    }
}
?>
