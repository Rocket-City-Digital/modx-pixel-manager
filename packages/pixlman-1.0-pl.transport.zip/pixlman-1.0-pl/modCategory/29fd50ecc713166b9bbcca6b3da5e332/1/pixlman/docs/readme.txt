--------------------
Extra: Pixlman
--------------------
Version: 1.0
Since: November 24th, 2021
Author: Wayne Roddy <wayne@rocketcitydigital.com>

A MODX Extra to manage "Pixels", 3rd Party plugin embeds or general javascripts
